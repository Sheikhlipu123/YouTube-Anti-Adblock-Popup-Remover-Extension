// Remove the popups
function removePopups() {
  setInterval(() => {
    const fullScreenButton = document.querySelector(".ytp-fullscreen-button");
    const modalOverlay = document.querySelector("tp-yt-iron-overlay-backdrop");
    const popup = document.querySelector(".style-scope ytd-enforcement-message-view-model");
    const popupButton = document.getElementById("dismiss-button");

    const video1 = document.querySelector("#movie_player > video.html5-main-video");
    const video2 = document.querySelector("#movie_player > .html5-video-container > video");

    const bodyStyle = document.body.style;

    bodyStyle.setProperty('overflow-y', 'scroll', 'important');

    if (modalOverlay) {
      modalOverlay.removeAttribute("opened");
      modalOverlay.remove();
    }

    if (popup) {
      if (popupButton) popupButton.click();
      popup.remove();
    }

    if (video1 && video1.paused) {
      // Simulate pressing the spacebar to pause the video
      video1.dispatchEvent(new KeyboardEvent("keydown", { key: " " }));
    }

    if (video2 && video2.paused) {
      // Simulate pressing the spacebar to pause the video
      video2.dispatchEvent(new KeyboardEvent("keydown", { key: " " }));
    }
  }, 1000);
}
