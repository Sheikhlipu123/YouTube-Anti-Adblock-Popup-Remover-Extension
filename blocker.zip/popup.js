// popup.js

document.getElementById("visitGitHubButton").addEventListener("click", function() {
  // Open your GitHub page in a new tab when the button is clicked
  chrome.tabs.create({ url: "https://github.com/sheikhlipu123" });
});
