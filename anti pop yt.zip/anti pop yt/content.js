// This code should be placed in your content.js file

// Specify domains and JSON paths to remove
const domainsToRemove = [
  '*.youtube-nocookie.com/*'
];
const jsonPathsToRemove = [
  'playerResponse.adPlacements',
  'playerResponse.playerAds',
  'adPlacements',
  'playerAds',
  'playerConfig',
  'auxiliaryUi.messageRenderers.enforcementMessageViewModel'
];

// Function to remove JSON paths
function removeJsonPaths(domains, jsonPaths) {
  const currentDomain = window.location.hostname;
  if (!domains.includes(currentDomain)) return;

  jsonPaths.forEach(jsonPath => {
    const pathParts = jsonPath.split('.');
    let obj = window;
    for (const part of pathParts) {
      if (obj.hasOwnProperty(part)) {
        obj = obj[part];
      } else {
        break;
      }
    }
    obj = undefined;
  });
}

// Remove the popups
function removePopups() {
  setInterval(() => {
    const fullScreenButton = document.querySelector(".ytp-fullscreen-button");
    const modalOverlay = document.querySelector("tp-yt-iron-overlay-backdrop");
    const popup = document.querySelector(".style-scope ytd-enforcement-message-view-model");
    const popupButton = document.getElementById("dismiss-button");

    const video1 = document.querySelector("#movie_player > video.html5-main-video");
    const video2 = document.querySelector("#movie_player > .html5-video-container > video");

    const bodyStyle = document.body.style;

    bodyStyle.setProperty('overflow-y', 'scroll', 'important');

    if (modalOverlay) {
      modalOverlay.removeAttribute("opened");
      modalOverlay.remove();
    }

    if (popup) {
      if (popupButton) popupButton.click();
      popup.remove();
    }

    if (video1 && video1.paused) {
      video1.play();
    }

    if (video2 && video2.paused) {
      video2.play();
    }
  }, 1000);
}

// Call the functions to remove ads and popups
removeJsonPaths(domainsToRemove, jsonPathsToRemove);
removePopups();
